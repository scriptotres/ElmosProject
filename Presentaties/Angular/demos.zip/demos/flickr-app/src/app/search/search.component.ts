import { Photo } from './../models/photo';
import { FlickrService } from './../services/flickr.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})

export class SearchComponent implements OnInit {
  query: string;
  results: object;

  constructor(private flickrService:FlickrService, private router: Router, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {this.query = params["query"]});
   }

   search():void{
     console.info('this query: ', this.query);
     if(!this.query){
       return;
     }

     this.flickrService.searchPhotos(this.query).subscribe((res:Photo[]) => this.renderPhotos(res));
   }

   renderPhotos(res:Photo[]){
     this.results = res;
   }

   submit(query:string):void{
     this.router.navigate(['search'], {queryParams: {query}}).then(_=>this.search());
   }

  ngOnInit() {
   this.search();
  }

}
