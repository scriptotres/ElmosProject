import {
  async,
  inject,
  fakeAsync
} from '@angular/core/testing'

import {Router} from '@angular/router';
import {Location} from '@angular/common';
