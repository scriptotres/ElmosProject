import { Photo, Photos, RootObject } from './../models/photo';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';



@Injectable({
  providedIn: 'root'
})
export class FlickrService {

  static BASE_URL= "https://api.flickr.com/services/rest/";

  constructor(private http:HttpClient) {}

  query(url:string, params?: Array<string>):Observable<any>{
    let queryUrl = `${FlickrService.BASE_URL}${url}`;
    if(params){
      queryUrl = `${queryUrl}&api_key=${environment.flickrApiKey}&${params.join('&')}`;
    }
    /*
    return this.http.get<Photos>(queryUrl).pipe(
      map((result) => {
        return result["photos"].photo
      })
    );*/

    return this.http.get<RootObject>(queryUrl).pipe(
      map((result)=>{
        let photos:Photo[] = [];
        for(let i = 0, l = result.photos.photo.length ; i < l ;i++){
            let o = result.photos.photo[i];
            photos.push(new Photo(o.id, o.secret, o.server, o.farm, o.title));
        }

        return photos;
      })
    );
                  
  }

   searchPhotos(query: string){
     return this.query('?method=flickr.photos.search', [`tags=${query}`, `format=json`, `nojsoncallback=1`]);
   }
}


/*https://blog.angular-university.io/angular-http/ */