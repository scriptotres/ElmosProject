
import { FlickrApiKey } from "./../../environments/flickrApiKey";
import { inject, fakeAsync, tick, TestBed, getTestBed } from "@angular/core/testing";
import { environment } from 'src/environments/environment';
import { FlickrService } from "../services/flickr.service";
import {
  HttpClientTestingModule,
  HttpTestingController
} from "@angular/common/http/testing";

import { IPhoto, Photo } from "../models/photo";

describe("FlickrService", () => {
  let injector: TestBed;
  let service: FlickrService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FlickrService],
      imports: [HttpClientTestingModule]
    });
  });

  beforeEach(() => {
    injector = getTestBed();
    httpMock = injector.get(HttpTestingController);
    service = injector.get(FlickrService);
  });

  it("should return an observable of photos", () => {
    const dummyPhotos = [ new Photo("id","secret","server", 5, "test foto")];
    
    service.searchPhotos("elmos").subscribe((photos:IPhoto[]) => {
      expect(photos.length).toBe(1);
      expect(photos).toEqual(dummyPhotos);
    })

    const req = httpMock.expectOne(`https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=${environment.flickrApiKey}&tags=elmos&format=json&nojsoncallback=1`);
    expect(req.request.method).toBe("GET");
    req.flush(dummyPhotos);
  });

  afterEach(() => {
    // after every test, assert that there are no more pending requests
    httpMock.verify();
  });
});
