export interface IPhoto {
    id: string;
    owner: string;
    secret: string;
    server: string;
    farm: number;
    title: string;
    ispublic: number;
    isfriend: number;
    isfamily: number;
}

export interface IPhotos {
    page: number;
    pages: number;
    perpage: number;
    total: string;
    photo: IPhoto[];
}

export class RootObject {
    photos: IPhotos;
    stat: string;
}


export class Photo implements IPhoto {
    id: string;
    owner: string;
    secret: string;
    server: string;
    farm: number;
    title: string;
    ispublic: number;
    isfriend: number;
    isfamily: number;

    constructor(id: string, secret: string, server: string, farm: number, title: string ){
        this.id = id;
        this.secret = secret;
        this.server = server;
        this.farm = farm;
        this.title = title;
    }

    toUrl(){
        return `https://farm${this.farm}.staticflickr.com/${this.server}/${this.id}_${this.secret}.jpg`
    }

}

export class Photos implements IPhotos{
    page: number;
    pages: number;
    perpage: number;
    total: string;
    photo: IPhoto[];
}