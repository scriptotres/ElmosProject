import { Injectable }  from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';


@Injectable()
export class SpotifyService{
    static BASE_URL = "https://api.spotify.com/v1";

    constructor(private http: HttpClient){}

    query(URL:string, params?: Array<string>):Observable<any>{
        let queryUrl = `${SpotifyService.BASE_URL}${URL}`;
        if(params){
            queryUrl = `${queryUrl}?${params.join('&')}`;
        }
       
        const apiKey = environment.spotifyApiKey;
        const headers = new HttpHeaders({
            Authorization: `Bearer ${apiKey}`
        })

        const options = {
            headers
        };

        return this.http.get(queryUrl, options);
    }

   search(query:string, type:string){
       return this.query("/search", [`q=${query}`, `type=${type}`])
   }

   searchTrack(query:string){
       return this.search(query, 'track');
   }
}

export const SPOTIFY_PROVIDERS: Array<any> = [
    {provide: SpotifyService, useClass: SpotifyService}
];

//https://www.telerik.com/blogs/updating-to-angular-httpclient-simpler-http-calls