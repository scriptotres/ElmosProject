import { IPhoto } from './../models/photo';
import { IAppState } from './../app.store';
import { Component, OnInit } from '@angular/core';
import { NgRedux, select } from '@angular-redux/store';
import { Photo } from '../models/photo';
import { ADD_PHOTO, REMOVE_PHOTO } from '../app.photos.actions';
import {FormBuilder, FormGroup, Validators, AbstractControl } from'@angular/forms';

@Component({
  selector: 'app-photo-list',
  templateUrl: './photo-list.component.html',
  styleUrls: ['./photo-list.component.scss']
})
export class PhotoListComponent implements OnInit {
  /*photos: Photo[] = [
    new Photo("https://picsum.photos/g/500?random","random photo"),
    new Photo("https://picsum.photos/g/500?random","random photo"),
    new Photo("https://picsum.photos/g/500?random","random photo")
  ];*/

  @select() photos:IPhoto[];
  @select() lastUpdate;

  flickrForm: FormGroup;
  url: AbstractControl;

  constructor(private ngRedux: NgRedux<IAppState>, fb:FormBuilder) { 
    this.flickrForm = fb.group({
      'url': ['', Validators.required]
    });

    this.url = this.flickrForm.controls['url']; 
  }


  addImage(newLink, newTitle){
    /*this.photos.unshift(
      new Photo(newLink.value, newTitle.value)
    )*/

    this.ngRedux.dispatch({type: ADD_PHOTO, photo: new Photo(newLink.value, newTitle.value)});
    return false;
  }

  deletePhoto(photo:Photo){
    this.photos.splice(this.photos.indexOf(photo), 1);
    this.ngRedux.dispatch({type: REMOVE_PHOTO, photo });
  }


  ngOnInit() {
    console.log("component init");
  }

}
