import { Component, OnInit } from '@angular/core';
import { Photo } from '../models/photo';

@Component({
  selector: 'app-photo-list',
  templateUrl: './photo-list.component.html',
  styleUrls: ['./photo-list.component.scss']
})
export class PhotoListComponent implements OnInit {
  photos: Photo[] = [
    new Photo("https://picsum.photos/g/500?random","random photo"),
    new Photo("https://picsum.photos/g/500?random","random photo"),
    new Photo("https://picsum.photos/g/500?random","random photo")
  ];

  constructor() { }


  addImage(newLink, newTitle){
    this.photos.unshift(
      new Photo(newLink.value, newTitle.value)
    )
    return false;
  }

  deletePhoto(photo:Photo){
    this.photos.splice(this.photos.indexOf(photo), 1);
  }


  ngOnInit() {
  }

}
