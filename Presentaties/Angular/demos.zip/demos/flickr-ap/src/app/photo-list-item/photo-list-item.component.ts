import { Photo } from "./../models/photo";
import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";


@Component({
  selector: "app-photo-list-item",
  templateUrl: "./photo-list-item.component.html",
  styleUrls: ["./photo-list-item.component.scss"]
})
export class PhotoListItemComponent implements OnInit {
  /*photo: Photo = new Photo(
    "https://picsum.photos/g/500?random",
    "random photo"
  );
  */



  @Input() photo:Photo;
  @Output() delete: EventEmitter<Photo>;
  
  constructor() {
    this.delete = new EventEmitter();
  }
  
  deletePhoto(){
    this.delete.emit(this.photo);
  }
  
  ngOnInit() {}
}


/*

@Output() putRingOnIt: EventEmitter<string>;
constructor() {
this.putRingOnIt = new EventEmitter();
}
liked(): void { this.putRingOnIt.emit("oh oh oh");
}

*/