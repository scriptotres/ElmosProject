

export interface IPhoto {
    url: string;
    title: string;

    toUrl():string;
}

export class Photo implements Photo{

    constructor(public url:string, public title:string){}

    toUrl():string{
        return this.title;
    }
}


