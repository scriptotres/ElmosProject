import { IAppState, INITIAL_STATE, rootReducer } from './app.store';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ FormsModule, ReactiveFormsModule}from'@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloWorldComponent } from './hello-world/hello-world.component';
import { PhotoDetailsComponent } from './photo-details/photo-details.component';
import { PhotoListComponent } from './photo-list/photo-list.component';
import { PhotoListItemComponent } from './photo-list-item/photo-list-item.component';

import { NgRedux, NgReduxModule } from '@angular-redux/store';

@NgModule({
  declarations: [
    AppComponent,
    HelloWorldComponent,
    PhotoDetailsComponent,
    PhotoListComponent,
    PhotoListItemComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    NgReduxModule
  ],
  providers: [],
  bootstrap: [AppComponent, PhotoListComponent]
})
export class AppModule { 

  constructor (ngRedux: NgRedux<IAppState>) {
    console.log(INITIAL_STATE);
    ngRedux.configureStore(rootReducer, INITIAL_STATE);
}

}
