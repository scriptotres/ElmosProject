export const SHOW_ALL_PHOTOS = 'SHOW_ALL';
export const ADD_PHOTO = 'ADD_PHOTO';
export const REMOVE_PHOTO = 'REMOVE_PHOTO';
