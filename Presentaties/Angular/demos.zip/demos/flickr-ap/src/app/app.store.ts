import { IPhoto, Photo } from "./models/photo";
import { SHOW_ALL_PHOTOS, ADD_PHOTO, REMOVE_PHOTO } from "./app.photos.actions";

export interface IAppState {
  photos: IPhoto[];
  lastUpdate: Date;
}
export const INITIAL_STATE: IAppState = {
  photos: [
    new Photo("https://picsum.photos/g/500?random","random photo"),
    new Photo("https://picsum.photos/g/500?random","random photo"),
    new Photo("https://picsum.photos/g/500?random","random photo")
  ],
  lastUpdate: null
};

export function rootReducer(state, action) {
  console.log("reducing shizzl");
  switch (action.type) {
    case ADD_PHOTO:
    
      return Object.assign({}, state, {
        photos: state.photos.concat(Object.assign({}, action.photo)),
        lastUpdate: new Date()
      });
    case REMOVE_PHOTO:
      
      let index = state.photos.indexOf(action.photo);
      return Object.assign({}, state, {
        photos: [
          ...state.photos.slice(0, index),
          Object.assign({}, action.photo),
          ...state.photos.slice(index + 1)
        ]
      });
  }
  return state;
}


//https://medium.com/codingthesmartway-com-blog/angular-and-redux-ecd22ea53492