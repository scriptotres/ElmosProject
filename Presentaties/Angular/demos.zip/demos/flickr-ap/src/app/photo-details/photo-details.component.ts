import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photo-details',
  templateUrl: './photo-details.component.html',
  styleUrls: ['./photo-details.component.scss']
})
export class PhotoDetailsComponent implements OnInit {
  isImageLoaded: boolean = false;
  url: string = "https://picsum.photos/g/500?random";
  title: string = "random photo";

  imageLoaded(){
    this.isImageLoaded = true;
  }

  constructor() { }

  ngOnInit() {
  }

}
